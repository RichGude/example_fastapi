from .orjson import *

__doc__ = orjson.__doc__
