# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# Copyright (c) 2016 Colin Duquesnoy (QCrash project)
# Copyright (c) 2018- Spyder Project Contributors
#
# Licensed under the terms of the MIT License
# (see LICENSE.txt in the parent directory for details)
# -----------------------------------------------------------------------------

"""
Tests for the Github login dialog and backend from QCrash.

Some tests defined in this module were adapted from the
`QCrash Project <https://github.com/ColinDuquesnoy/QCrash>`_.
"""
