# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# Copyright (c) 2016 Colin Duquesnoy (QCrash project)
# Copyright (c) 2018- Spyder Project Contributors
#
# Licensed under the terms of the MIT License
# (see LICENSE.txt in this directory for details)
# -----------------------------------------------------------------------------

"""
spyder.widgets.github
=====================

Widgets defined in this module were adapted from the
`QCrash Project <https://github.com/ColinDuquesnoy/QCrash>`_.
"""
