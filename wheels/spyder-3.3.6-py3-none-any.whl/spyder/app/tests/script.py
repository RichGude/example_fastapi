#%%
a = 10


#%%
li = [1, 2, 3]

#%%
import numpy as np
arr = np.array(li)
