#%%

# pylint: enable=C0111
# pylint: enable=C0103
# pylint: enable=C0413

a = 10


#%%
li = [1, 2, 3]

#%%
import numpy as np
arr = np.array(li)
