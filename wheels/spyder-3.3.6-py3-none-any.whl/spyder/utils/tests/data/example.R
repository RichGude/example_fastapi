hello <- function( name ) {
    sprintf( "Hello, %s", name );
}
