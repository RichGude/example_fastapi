*Italic*
**Bold**
# Heading 1
=========	
## Heading 2
---------	
[Link](http://a.com)	
[Link][1]
[1]: http://b.org
![Image](http://url/a.png)
![Image][1]
[1]: http://url/b.jpg
> Blockquote
A paragraph.
A paragraph after 1 blank line.
	
* List
* List
* List

- List
- List
- List

1. One
2. Two
3. Three

1) One
2) Two
3) Three

---	Horizontal Rule

***	Horizontal Rule
`Inline code` with backticks
```
# code block
print '3 backticks or'
print 'indent 4 spaces'
```

under_score
