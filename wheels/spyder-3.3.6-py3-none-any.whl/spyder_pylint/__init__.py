# -*- coding: utf-8 -*-

#==============================================================================
# The following statement is required to register this 3rd party plugin:
#==============================================================================
from .pylint import Pylint as PLUGIN_CLASS
